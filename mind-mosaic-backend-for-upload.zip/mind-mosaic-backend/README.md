# Mind Mosaic Backend

This is the backend server for the Mind Mosaic project built with Node.js, Express, and MongoDB.